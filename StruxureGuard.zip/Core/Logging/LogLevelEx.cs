namespace StruxureGuard.Core.Logging;

public enum LogLevelEx
{
    Trace,
    Debug,
    Info,
    Warn,
    Error,
    Fatal
}
